<?php

/** @generate-function-entries */

/** @param string|int $text */
function ctype_alnum(mixed $text): bool {}

/** @param string|int $text */
function ctype_alpha(mixed $text): bool {}

/** @param string|int $text */
function ctype_cntrl(mixed $text): bool {}

/** @param string|int $text */
function ctype_digit(mixed $text): bool {}

/** @param string|int $text */
function ctype_lower(mixed $text): bool {}

/** @param string|int $text */
function ctype_graph(mixed $text): bool {}

/** @param string|int $text */
function ctype_print(mixed $text): bool {}

/** @param string|int $text */
function ctype_punct(mixed $text): bool {}

/** @param string|int $text */
function ctype_space(mixed $text): bool {}

/** @param string|int $text */
function ctype_upper(mixed $text): bool {}

/** @param string|int $text */
function ctype_xdigit(mixed $text): bool {}
